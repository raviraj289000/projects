export const USERS = [
    {id: 1, name: 'Manoj', playlistID: 1},
    {id: 2, name: 'David', playlistID: 2}
  ];