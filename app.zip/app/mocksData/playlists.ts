    
export const PLAY_LISTS = [
    {
      id: 1, videos: [
        { title: 'Angular 1.5', time: '12:30'},
        { title: 'React', time: '12:30'},
        { title: 'Angular 2', time: '10:00'},
        { title: 'Angular Router', time: '7'},
        { title: 'Angular Animations', time: '6'},
        { title: 'Angular Srs', time: '9:40'},
        { title: 'Angular Seo', time: '3'},
        { title: 'Redux', time: '8:30'},
        { title: 'Angular 4', time: '19:10'},
        { title: 'Flexbox', time: '12:30'},
        { title: 'React', time: '12:30'},
        { title: 'Angular Forms', time: '14:50'},
        { title: 'Angular Directives', time: '3'},
        { title: 'Angular Ngrx', time: '19:10'},
        { title: 'Angular Redux', time: '19:10'},
        { title: 'Css', time: '5:30'},
        { title: 'Html', time: '2:30'},
        { title: 'React', time: '12:30'},
        { title: 'RxJS', time: '1:30'}
      ]
    },
    {
      id: 2, videos: [
        { title: 'Angular 1.5', time: '12:30'},
        { title: 'React', time: '12:30'},
        { title: 'Redux', time: '8:30'},
        { title: 'Angular 4', time: '62:10'},
        { title: 'Flexbox', time: '12:30'},
        { title: 'Css', time: '5:30'},
        { title: 'Flexbox', time: '12:30'},
        { title: 'Angular 2', time: '16:30'},
        { title: 'Html', time: '2:30'},
        { title: 'Flexbox', time: '12:30'},
        { title: 'RxJS', time: '1:30'}
      ]
    }
  ];